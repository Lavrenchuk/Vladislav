 1 class SimpleIterator(object):
 2     
 3     def __init__(self,fname):
 4         self.fd = open(fname,'r')
 5         
 6     def __iter__(self):
 7         return self
 8 
 9     def next(self):
10         l = self.fd.readline()
11         if l != '':
12             l = l.rstrip('\n')
13             num = int(l)
14             return num*2
15         raise StopIteration

